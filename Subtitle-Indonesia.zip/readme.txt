SUBTITLE INDONESIA v4.1 — MOD SPARTANPORT
Isi: EXEC/WAD/PS4_LE/R_LANG_EN.WAD (456.432 byte) = terjemahan penuh v4.0
ditambah nama-nama tempat (Makam Ares, Kota Olympia, Labirin, dll.) dan
peringkat 'Olimpik!'. Pasang: letakkan zip di folder mods
(~/.local/share/spartanport/mods/), JANGAN di-unzip — launcher membongkar
sendiri. Di game: bahasa English + subtitle ON. Mematikan: uncheck mod
di halaman Mods — file game asli tidak pernah diubah.
